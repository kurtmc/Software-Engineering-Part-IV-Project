package com.company;

public class Main {

    /**
     * Compute factorial of n
     * @param n, assume n >= 0
     * @return the factorial of n
     */
    public static int factorial(int n) {
        return 0;
    }

    /**
     * The Fibonacci sequence starts at 0. The sequence starts like this:
     * 0, 1, 1, 2, 3, 5, 8, 13, 21, ...
     * @param n is the index of the number in the fibonacci sequence
     * @return the nth number in the fibonacci sequence
     */
    public static int fibonacci(int n) {
        return 0;
    }

    /**
     * Calculate the minimum integer from a list
     *
     * @param numbers list of integers
     * @return the minimum
     */
    public static int min(int[] numbers) {
        return 0;
    }

    /**
     * Calculate the maximum integer from a list
     *
     * @param numbers list of integers
     * @return the maximum
     */
    public static int max(int[] numbers) {
    	int min = numbers[0];
    	for(int i=0; i<numbers.length; i++){
    		if(min<numbers[i]){
    			min=numbers[i];
    		}
    		
    	}
    	
        return min;
    }

    /**
     * Reverse a list of integers
     * @param list of integers
     * @return the reversed list
     */
    public static int[] reverse(int[] list) {
        return null;
    }

    /**
     * Check if a word is a palindrome
     * @param word - string to check
     * @return true or false
     */
    public static boolean isPalindrome(String word) {
        return false;
    }

    /**
     * Write a function that combines two lists by alternately taking elements, e.g. [a,b,c], [1,2,3] → [a,1,b,2,c,3]
     * Assume list1 and list2 are of the same length
     * @param list1 - list of integers
     * @param list2 - list of integers
     * @return shuffled list of integers
     */
    public static int[] shuffle(int[] list1, int[] list2) {
        return null;
    }

    /**
     * Write a function that rotates a list by k elements. For example [1,2,3,4,5,6] rotated by two becomes [3,4,5,6,1,2]
     * @param list of integers
     * @param k - amount to rotate by
     * @return rotated list
     */
    public static int[] rotate(int[] list, int k) {
        return null;
    }
}
