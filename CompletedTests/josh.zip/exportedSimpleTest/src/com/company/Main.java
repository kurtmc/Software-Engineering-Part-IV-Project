package com.company;

public class Main {

    /**
     * Compute factorial of n
     * @param n, assume n >= 0
     * @return the factorial of n
     */
    public static int factorial(int n) {
        if (n==0){
        	return 1;
        }
    	return factorial(n-1)*n;
    }

    /**
     * The Fibonacci sequence starts at 0. The sequence starts like this:
     * 0, 1, 1, 2, 3, 5, 8, 13, 21, ...
     * @param n is the index of the number in the fibonacci sequence
     * @return the nth number in the fibonacci sequence
     */
    public static int fibonacci(int n) {
    	if (n == 0){
    		return 0;
    	}
    	if (n ==1){
    		return 1;
    		
    	}
    	return fibonacci(n-2)+fibonacci(n-1);
    }

    /**
     * Calculate the minimum integer from a list
     *
     * @param numbers list of integers
     * @return the minimum
     */
    public static int min(int[] numbers) {
        int min = Integer.MAX_VALUE;
        for (int i =0; i< numbers.length; i++){
        	if (numbers[i]<min){
        		min = numbers[i];
        	}
        }
    	return min;
    }

    /**
     * Calculate the maximum integer from a list
     *
     * @param numbers list of integers
     * @return the maximum
     */
    public static int max(int[] numbers) {
    	int max = -Integer.MAX_VALUE;
        for (int i =0; i< numbers.length; i++){
        	if (numbers[i]>max){
        		max = numbers[i];
        	}
        }
    	return max;
    }

    /**
     * Reverse a list of integers
     * @param list of integers
     * @return the reversed list
     */
    public static int[] reverse(int[] list) {
    	int pointer = list.length-1;
       int[] reversed = new int[list.length];
       for (int i=0; i<list.length; i++){
    	   reversed[i]=list[pointer];
    	   pointer--;
        }
    	return reversed;
    }

    /**
     * Check if a word is a palindrome
     * @param word - string to check
     * @return true or false
     */
    public static boolean isPalindrome(String word) {
        boolean isPalindrome = true;
        char[] chars = word.toCharArray();
        int count = chars.length-1;
        for (int i=0; i<chars.length; i++){
        	if (chars[count] != chars[i]){
        		isPalindrome = false;
        	}
        	count--;
        }
        
        return isPalindrome;
    	
    	
    }

    /**
     * Write a function that combines two lists by alternately taking elements, e.g. [a,b,c], [1,2,3] → [a,1,b,2,c,3]
     * Assume list1 and list2 are of the same length
     * @param list1 - list of integers
     * @param list2 - list of integers
     * @return shuffled list of integers
     */
    public static int[] shuffle(int[] list1, int[] list2) {
    	int[] shuffledList = new int[list1.length*2];
    	int count = 0;
    	for (int i=0; i<list1.length; i++){
    		shuffledList[count] = list1[i];
    		count++;
    		shuffledList[count] = list2[i];
    		count++;
    	}
        return shuffledList;
    }

    /**
     * Write a function that rotates a list by k elements. For example [1,2,3,4,5,6] rotated by two becomes [3,4,5,6,1,2]
     * @param list of integers
     * @param k - amount to rotate by
     * @return rotated list
     */
    public static int[] rotate(int[] list, int k) {
        int count = 0;
        while(count<k){
        	list = addOnce(list);
        }
    	
    	return null;
    }
    
    public static int[] addOnce(int[] list){
    	return null;
    }
    
}
